<?php

$renzxhosting = 'wukongmania@gmail.com'; // EMAIL KAMU

$renzhosting = 'Jangan Hapus Copyright'; // NO REEDIT

?>